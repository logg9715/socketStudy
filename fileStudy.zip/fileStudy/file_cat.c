#include <stdio.h>

int main(int argc, char* argv[])
{
	// 파일 읽는 구조체
	FILE *src;
	char ch;

	// 2번째 명령인수의 파일을 src와 읽기모드로 연결
	src = fopen(argv[1], "r");
	// 파일 끝을 읽으면 반복 종료
	while (!feof(src))
	{
		// 현재 가리키는 문자를 읽고 다음 문자를 가리킴
		ch = (char)fgetc(src);
		// ch가 문자열 끝이 아니면 콘솔에 출력
		if (ch != EOF)
			printf("%c", ch);
	}
	
	// 스트림 닫기
	fclose(src);
}

