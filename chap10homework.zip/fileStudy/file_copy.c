#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

int main(int argc, char* argv[])
{
	FILE *src;
	FILE *dst;
	char ch;

	int count = 0;

	/*
	 * 명령인수를 이상하게 입력받았을때 예외처리
	 */
	if (argc < 3)
	{
		printf("최소 2개의 명령 인수를 입력하시오.\n");
		exit(1);
	}

	/*
	 *2번째 명령인수=첫 번째로 입력한 파일을 읽고 src에 연결
	 */
	if ((src=fopen(argv[1], "r")) == NULL )
	{
		perror("fopen:src");
		exit(1);
	}

	/*
	 * 3번째 명령인수=두 번째로 입력한 파일명의 파일을 열고 dst와 연결
	 */
	if ((dst = fopen(argv[2], "w")) == NULL)
	{
		perror("fopen:dst");
		exit(1);
	}

	/*
	 * src의 문자를 가리키는 포인터가 EOF=끝 에 가게 되면 종료
	 * 파일의 끝을 읽으면 1을 반환
	 */
	while (!feof(src)) 
	{
		ch = (char)fgetc(src); // 현재 가리키고 있는 문자를 출력하고 다음 문자를 가리킴
		if (ch != EOF) // EOF가 아니면 ch에 읽어들인 문자를 dst에 작성
			fputc((int)ch, dst); // 문자를 작성하고 다음 문자칸을 가리킴
		count++;
	}
	/*
	 * 스트림 닫기
	 */
	fclose(src);
	fclose(dst);
}

