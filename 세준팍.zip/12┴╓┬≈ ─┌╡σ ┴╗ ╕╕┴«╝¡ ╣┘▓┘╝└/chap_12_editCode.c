/* 구동 시 오류 로그 작성 */

if ((s_sock = socket(PF_INET, SOCK_STREAM, 0)) < 0)
{
	web_log(ERROR, "SYSCALL", "web server listen sockek open error", s_sock);
}

port = atoi(argv[1]);
if (port > 60000)
	web_log(ERROR, "ERROR", "invalid port number", port);

memset(&s_addr, 0, sizeof(s_addr));
s_addr.sin_family = AF_INET;
s_addr.sin_addr.s_addr = htonl(INADDR_ANY);
s_addr.sin_port = htons(port);

if (bind(s_sock, (struct sockaddr *)&s_addr, sizeof(s_addr)) < 0)
	web_log(ERROR, "ERROR", "server cannot bind", 0);

listen(s_sock, 10);
web_log(LOG, "STATUS", "web server is listening from port ", port);


/* gpio 초기화 */

wiringPiSetup();

pinMode(LED, OUTPUT);
digitalWrite(LED, 0);

softToneCreate (PIN);
softToneWrite (PIN, 0);


/* gpio 관련 스레드 실행 */

if (strstr(rcvBuf, "LED_ON") != NULL)
    {
        led_status = 1;
        res = pthread_create(&tled, NULL, do_led, NULL);
        web_log(LOG, "LED", "led is turned on", 1);
    }

    if (strstr(rcvBuf, "LED_OFF") != NULL)
    {
        led_status = 0;
        res = pthread_create(&tled, NULL, do_led, NULL);
        web_log(LOG, "LED", "led is turned off", 0);
    }
	
	if (strstr(rcvBuf, "BUZ_ON") != NULL)
    {
        buz_status = 1;
        res = pthread_create(&tbuz, NULL, do_buzzer, NULL);
        web_log(LOG, "BUZ", "buz is turned on", 1);
    }

    if (strstr(rcvBuf, "BUZ_OFF") != NULL)
    {
        buz_status = 0;
        res = pthread_create(&tbuz, NULL, do_buzzer, NULL);
        web_log(LOG, "BUZ", "buz is turned off", 0);
	}
}


/* gpio 동작 함수 */

void *do_led(void *arg)
{
    if (led_status == 1)
        digitalWrite(LED,1);
    else
        digitalWrite(LED,0);
}

void *do_buzzer(void *arg)
{
	if (buz_status == 1)
        softToneWrite (PIN, 262);
    else
	{
        softToneWrite (PIN, 0);
		digitalWrite(PIN, 0);
	}
}
