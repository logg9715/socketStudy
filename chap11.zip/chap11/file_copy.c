#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

#define MAX_READ 10

int main(int argc, char* argv[]) 
{
	int src_fd;
	int dst_fd;
	char buf[MAX_READ];
	ssize_t rcnt;
	ssize_t tot_cnt = 0;
	mode_t mode = 0644;

	src_fd = open(argv[1], O_RDONLY);
	dst_fd = creat(argv[2], mode);

	while ((rcnt = read(src_fd, buf, MAX_READ) )> 0)
	{
		tot_cnt += write(dst_fd, buf, rcnt);
	}

	printf("total write count = %d\n", tot_cnt);
	
	close(src_fd);
	close(dst_fd);

	return 0;
}


