#include <stdio.h>

void proc_usa()
{
	printf("This is USA()\n");
}
