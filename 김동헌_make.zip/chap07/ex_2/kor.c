#include <stdio.h>

void proc_kor()
{
	printf("This is Kor()\n");
}
