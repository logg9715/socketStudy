#include "main.h"

int main()
{
	printf("This is main()\n");

	proc_kor();
	proc_usa();

	return 0;
}
