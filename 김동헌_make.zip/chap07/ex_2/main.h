#include <stdio.h>

void proc_kor();
void proc_usa();
