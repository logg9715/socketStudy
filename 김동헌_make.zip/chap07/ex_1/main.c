#include <stdio.h>

#include "example.h"

int main()
{
	int year = YEAR;
	printf("This year is %d\n", year);
	search();
	update();
}
