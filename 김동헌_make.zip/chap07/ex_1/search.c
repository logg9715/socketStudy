#include <stdio.h>

void search()
{
	printf("This is a search function\n");
	printf("This is a search function\n");
	printf("This is a search function\n");
}

