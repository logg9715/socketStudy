#include <stdio.h>

void update()
{
	printf("this is a update funtion \n");
}

